from gitflow_visualizer import run
import sys

def main():
    run.main()
